# OwlQuery-AnimalUI

OwlQuery Search Engine Frontend - A lightweight, modern universal search engine interface.

> Backend Repository: [OwlQuery](https://github.com/zealis/OwlQuery)

> [中文](README.md) | English

UI Design Reference: [animal-crossing-ui](https://github.com/guokaigdg/animal-crossing-ui)

## Tech Stack

- **Native HTML5** - Semantic page structure
- **Tailwind CSS (Browser)** - Atomic CSS framework
- **Native JavaScript (ES6+)** - No framework dependency, lightweight and efficient
- **Lucide Icons** - Open source icon library
- **FTS5 Full-Text Search** - Backend based on SQLite FTS5 full-text search
- **Animal Crossing UI** - Design style reference

## Features

### Implemented

- **Light/Dark Theme Toggle** - Supports light/dark mode, auto-follows system
- **Search Function** - Keyword search, search result pagination
- **Search Stats** - Shows search time, result count
- **Trending Search** - Real-time trending list
- **Related Search** - Smart related recommendations
- **Quick Settings** - Safe search, search stats, related search toggles
- **Responsive Design** - Adapts to desktop and mobile
- **Smooth Routing** - Seamless transitions between pages
- **Click Tracking** - Search result click data collection
- **Feedback Feature** - Search result feedback (Related/Not interested/Feedback)
- **Custom JS Injection** - Supports adding third-party code like analytics
- **Frontend-Backend Separation** - Pure static frontend, deployable independently

### Not Implemented / TODO

- **Multilingual Support** - Internationalization (i18n)
- **Search Categories** - Filter by website category
- **Tag System** - Filter results by tags
- **User System** - Login, favorites, history
- **More Themes** - Custom theme colors
- **Search Suggestions** - Real-time suggestions while typing
- **Image Search** - Image search functionality
- **News Search** - News search functionality
- **Video Search** - Video search functionality
- **Subscription Updates** - Website content update subscriptions

## Project Structure

```
OwlQuery-AnimalUI/
├── pages/                  # HTML pages
│   ├── index.html         # Homepage
│   ├── results.html       # Search results page
│   └── settings.html      # Settings page
├── assets/                # Static assets
│   ├── css/
│   │   └── owl-theme.css  # Theme styles
│   ├── js/
│   │   ├── config.js      # Config file (backend API URL)
│   │   ├── custom.js      # Custom JS (analytics, etc.)
│   │   ├── owl-common.js  # Common scripts
│   │   ├── owl-nav.js     # Navigation interactions
│   │   ├── owl-results.js # Search results page logic
│   │   ├── owl-router.js  # Frontend router (SPA)
│   │   ├── owl-settings.js # Settings page logic
│   │   ├── lucide.min.js  # Icon library
│   │   └── tailwindcss-browser.js # Tailwind CSS
│   └── images/            # Image resources
├── DESIGN.md             # Design document
└── README.md
```

## Quick Start

> ⚠️ **Before Deployment**: Please modify the following configurations to your own website information, otherwise the frontend will not work properly.

### 1. Configure Backend URL (Required)

Edit `assets/js/config.js`, change `apiBase` to your backend API URL:

```javascript
var OwlConfig = {
  apiBase: 'https://your-api-domain.com'  // ← Change to your backend domain
};
```

- If frontend and backend are on the same domain (Nginx reverse proxy `/api/*`), keep default `/api`
- If backend is on a different server, enter the full backend URL (e.g., `https://api.yoursite.com`)

### 2. Add Custom JS (Optional)

Edit `assets/js/custom.js`, add third-party code like visitor analytics (Google Analytics, Baidu Tongji, etc.) in this file.

### Deployment

#### Method 1: Nginx Static Hosting (Recommended)

Upload the entire project directory to your server and configure Nginx:

> ⚠️ Please modify `yourdomain.com`, `/path/to/owlquery-frontend`, `backend:8080` in the config below to your own information.

```nginx
server {
    listen 80;
    server_name yourdomain.com;              # ← Change to your domain
    root /path/to/owlquery-frontend;         # ← Change to your frontend path
    index index.html;

    # API reverse proxy (if backend is on the same server)
    location /api/ {
        proxy_pass http://backend:8080;      # ← Change to your backend address
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Static asset caching
    location ~* \.(css|js|webp|png|jpg|jpeg|gif|svg|ico)$ {
        expires 12h;
    }

    # config.js no cache (takes effect immediately after modifying backend URL)
    location = /assets/js/config.js {
        expires -1;
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }
}
```

> 💡 If the backend is on a different server, you don't need to configure the `/api/` reverse proxy. Just fill in the full backend URL in `config.js` and configure CORS on the backend to allow your frontend domain.

#### Method 2: Any Static Hosting Service

Supports Vercel, Netlify, Cloudflare Pages, GitHub Pages, and any other static hosting service.

## Backend API

The frontend needs to connect to the backend API to work properly. Backend repository: [OwlQuery](https://github.com/zealis/OwlQuery)

### API Endpoint List

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/search` | GET | Search |
| `/api/trending` | GET | Trending search |
| `/api/related` | GET | Related search |
| `/api/click` | POST | Click tracking |
| `/api/feedback` | POST | Result feedback |
| `/api/settings` | GET | Settings config |
| `/health` | GET | Health check |

## Contact

For questions or copyright-related communication, please contact via Issue or email.
