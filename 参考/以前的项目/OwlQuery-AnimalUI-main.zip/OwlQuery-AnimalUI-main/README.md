# OwlQuery-AnimalUI

OwlQuery 搜索引擎前端 - 一个轻量级、现代化的通用搜索引擎界面。

> 后端仓库：[OwlQuery](https://github.com/zealis/OwlQuery)

> 中文 | [English](README.en.md)

UI 设计参考：[animal-crossing-ui](https://github.com/guokaigdg/animal-crossing-ui)

## 技术栈

- **原生 HTML5** - 语义化页面结构
- **Tailwind CSS (浏览器版)** - 原子化 CSS 框架
- **原生 JavaScript (ES6+)** - 无框架依赖，轻量高效
- **Lucide Icons** - 开源图标库
- **FTS5 全文搜索** - 后端基于 SQLite FTS5 的全文检索
- **Animal Crossing UI** - 设计风格参考

## 特性

### 已实现

- **明暗主题切换** - 支持浅色/深色模式，自动跟随系统
- **搜索功能** - 关键词搜索、搜索结果分页
- **搜索统计** - 显示搜索耗时、结果数量
- **热点搜索** - 实时热点榜单
- **相关搜索** - 智能相关推荐
- **快捷设置** - 安全搜索、搜索统计、相关搜索开关
- **响应式设计** - 适配桌面端和移动端
- **无刷新路由** - 页面间平滑过渡，提升体验
- **点击统计** - 搜索结果点击数据收集
- **反馈功能** - 搜索结果反馈（相关推荐/不感兴趣/反馈意见）
- **自定义 JS 注入** - 支持添加访客统计等第三方代码
- **前后端分离** - 纯静态前端，可独立部署

### 未实现 / 待开发

- **多语言支持** - 国际化（i18n）
- **搜索分类** - 按网站类别筛选
- **标签系统** - 按标签筛选结果
- **用户系统** - 登录、收藏、历史记录
- **更多主题** - 自定义主题色
- **搜索建议** - 输入时实时建议
- **图片搜索** - 图片搜索功能
- **新闻搜索** - 新闻搜索功能
- **视频搜索** - 视频搜索功能
- **订阅更新** - 网站内容更新订阅

## 项目结构

```
OwlQuery-AnimalUI/
├── pages/                  # HTML 页面
│   ├── index.html         # 首页
│   ├── results.html       # 搜索结果页
│   └── settings.html      # 设置页
├── assets/                # 静态资源
│   ├── css/
│   │   └── owl-theme.css  # 主题样式
│   ├── js/
│   │   ├── config.js      # 配置文件（后端 API 地址）
│   │   ├── custom.js      # 自定义 JS（访客统计等）
│   │   ├── owl-common.js  # 公共脚本
│   │   ├── owl-nav.js     # 导航栏交互
│   │   ├── owl-results.js # 搜索结果页逻辑
│   │   ├── owl-router.js  # 前端路由（无刷新加载）
│   │   ├── owl-settings.js # 设置页逻辑
│   │   ├── lucide.min.js  # 图标库
│   │   └── tailwindcss-browser.js # Tailwind CSS
│   └── images/            # 图片资源
├── DESIGN.md             # 设计文档
└── README.md
```

## 快速开始

> ⚠️ **部署前必读**：请务必将以下配置修改为你自己的网站信息，否则前端无法正常工作。

### 1. 配置后端地址（必改）

编辑 `assets/js/config.js`，将 `apiBase` 修改为你的后端 API 地址：

```javascript
var OwlConfig = {
  apiBase: 'https://your-api-domain.com'  // ← 改成你的后端域名
};
```

- 如果前后端同域名部署（Nginx 反代 `/api/*`），保持默认 `/api` 即可
- 如果后端在另一台服务器，填写后端完整地址（如 `https://api.yoursite.com`）

### 2. 添加自定义 JS（可选）

编辑 `assets/js/custom.js`，在此文件中添加访客统计等第三方代码（如 Google Analytics、百度统计）。

### 部署

#### 方式一：Nginx 静态托管（推荐）

将整个项目目录上传到服务器，配置 Nginx：

> ⚠️ 请将下面配置中的 `yourdomain.com`、`/path/to/owlquery-frontend`、`backend:8080` 修改为你自己的信息。

```nginx
server {
    listen 80;
    server_name yourdomain.com;              # ← 改成你的域名
    root /path/to/owlquery-frontend;         # ← 改成你的前端文件路径
    index index.html;

    # API 反向代理（如果后端在同服务器）
    location /api/ {
        proxy_pass http://backend:8080;      # ← 改成你的后端地址
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # 静态资源缓存
    location ~* \.(css|js|webp|png|jpg|jpeg|gif|svg|ico)$ {
        expires 12h;
    }

    # config.js 不缓存（修改后端地址后立即生效）
    location = /assets/js/config.js {
        expires -1;
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }
}
```

> 💡 如果后端在另一台服务器，不需要配置 `/api/` 反向代理，只需在 `config.js` 中填写后端完整地址，并在后端配置 CORS 允许你的前端域名访问。

#### 方式二：任意静态托管服务

支持 Vercel、Netlify、Cloudflare Pages、GitHub Pages 等任意静态托管服务。

## 后端 API

前端需要对接后端 API 才能正常工作。后端仓库地址：[OwlQuery](https://github.com/zealis/OwlQuery)

### API 接口列表

| 接口 | 方法 | 说明 |
|-----|------|------|
| `/api/search` | GET | 搜索 |
| `/api/trending` | GET | 热点搜索 |
| `/api/related` | GET | 相关搜索 |
| `/api/click` | POST | 点击统计 |
| `/api/feedback` | POST | 结果反馈 |
| `/api/settings` | GET | 设置配置 |
| `/health` | GET | 健康检查 |

## 联系方式

如有问题或版权相关沟通，请通过 Issue 或邮件联系。
