/* OwlQuery Results Page Scripts */

/* === API Configuration === */
var API_BASE = (typeof OwlConfig !== 'undefined' && OwlConfig.apiBase) || '/api';

function apiGet(path) {
  return fetch(API_BASE + path).then(function(r) { return r.json(); });
}

function apiPost(path, body) {
  return fetch(API_BASE + path, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(body)
  }).then(function(r) { return r.json(); });
}

/* === Search State === */
var currentQuery = '';
var currentPage = 1;

// Generate or retrieve a persistent session ID for co-occurrence mining.
function getSessionID() {
  var key = 'owl_sid';
  var sid = localStorage.getItem(key);
  if (!sid) {
    sid = 's_' + Date.now() + '_' + Math.random().toString(36).substring(2, 10);
    localStorage.setItem(key, sid);
  }
  return sid;
}

/* === Filter Tab Activation === */

/* === Clear Button for Search Input === */
function initClearButton() {
  var input = document.getElementById('topbar-search-input');
  var clearBtn = document.getElementById('topbar-clear-btn');
  if (!input || !clearBtn) return;

  function toggleClear() {
    clearBtn.style.display = input.value.length > 0 ? 'flex' : 'none';
  }

  input.addEventListener('input', toggleClear);

  clearBtn.addEventListener('click', function () {
    input.value = '';
    clearBtn.style.display = 'none';
    input.focus();
  });

  toggleClear();
}


function activateTab(btn) {
  var group = btn.parentElement;
  var siblings = group.querySelectorAll('.filter-tab');
  for (var i = 0; i < siblings.length; i++) {
    siblings[i].style.background = 'var(--owl-card)';
    siblings[i].style.color = 'var(--owl-foreground)';
    siblings[i].style.borderColor = 'var(--owl-glass-border)';
    siblings[i].classList.remove('active');
  }
  btn.style.background = '#0CC0B5';
  btn.style.color = '#FFF9E3';
  btn.style.borderColor = '#0CC0B5';
  btn.classList.add('active');
}

/* === Pagination Activation === */
function activatePage(btn) {
  var group = btn.parentElement;
  var siblings = group.querySelectorAll('.page-btn');
  for (var i = 0; i < siblings.length; i++) {
    siblings[i].style.background = 'var(--owl-card)';
    siblings[i].style.color = 'var(--owl-foreground)';
    siblings[i].style.borderColor = 'var(--owl-glass-border)';
    siblings[i].classList.remove('active');
  }
  btn.style.background = '#0CC0B5';
  btn.style.color = '#FFF9E3';
  btn.style.borderColor = '#0CC0B5';
  btn.classList.add('active');
}

/* === Perform Search === */
function performSearch(q, page) {
  currentQuery = q;
  currentPage = page || 1;
  var url = '/api/search?q=' + encodeURIComponent(q) + '&page=' + currentPage + '&page_size=20';
  // Send session ID for co-occurrence mining.
  fetch(url, { headers: { 'X-Session-ID': getSessionID() } })
    .then(function(r) { return r.json(); })
    .then(function(data) {
    var hasResults = (data.results || []).length > 0;
    renderResults(data);
    if (hasResults) {
      renderPagination(data);
    } else {
      var nav = document.getElementById('owl-pagination');
      if (nav) nav.innerHTML = '';
    }
    renderSidebar(data);
    updateStats(data);
  }).catch(function(err) {
    console.error('Search failed:', err);
  });
}

/* === Render Results === */
function renderResults(data) {
  var container = document.getElementById('owl-results-container');
  if (!container) return;
  container.innerHTML = '';
  var results = data.results || [];

  if (results.length === 0 && currentQuery) {
    renderNoResults(container, currentQuery);
    return;
  }

  results.forEach(function(result, index) {
    container.appendChild(createResultCard(result, index));
  });
  injectFeedbackButtons();
  if (window.lucide) lucide.createIcons();
}

/* === Render No Results (404-style) === */
function renderNoResults(container, query) {
  var wrapper = document.createElement('div');
  wrapper.style.cssText = 'display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 64px 24px; text-align: center; animation: owl-fade-in var(--owl-transition-slow) both;';

  // 404 code
  var codeEl = document.createElement('div');
  codeEl.style.cssText = 'font-family: var(--owl-font-display); font-size: 48px; font-weight: var(--owl-weight-black); color: var(--owl-muted); opacity: 0.35; line-height: 1; margin-bottom: 8px;';
  codeEl.textContent = '404';
  wrapper.appendChild(codeEl);

  var titleEl = document.createElement('h2');
  titleEl.style.cssText = 'font-family: var(--owl-font-display); font-size: var(--owl-text-xl); font-weight: var(--owl-weight-bold); color: var(--owl-foreground); margin-bottom: 8px;';
  titleEl.textContent = '\u672a\u627e\u5230\u76f8\u5173\u7ed3\u679c';
  wrapper.appendChild(titleEl);

  var descEl = document.createElement('p');
  descEl.style.cssText = 'font-size: var(--owl-text-sm); color: var(--owl-muted); font-weight: var(--owl-weight-medium); max-width: 400px; margin-bottom: 24px;';
  descEl.innerHTML = '\u672a\u627e\u5230\u4e0e <strong style=\"color: var(--owl-primary);\">' + escapeHtml(query) + '</strong> \u76f8\u5173\u7684\u7ed3\u679c\uff0c\u8bf7\u5c1d\u8bd5\u5176\u4ed6\u5173\u952e\u8bcd\u3002';
  wrapper.appendChild(descEl);

  var countdownEl = document.createElement('p');
  countdownEl.id = 'owl-no-results-countdown';
  countdownEl.style.cssText = 'font-size: var(--owl-text-xs); color: var(--owl-muted); margin-bottom: 16px;';
  countdownEl.textContent = '3 \u79d2\u540e\u81ea\u52a8\u8fd4\u56de\u9996\u9875...';
  wrapper.appendChild(countdownEl);

  var backBtn = document.createElement('button');
  backBtn.style.cssText = 'padding: 10px 28px; font-size: var(--owl-text-sm); font-weight: var(--owl-weight-bold); font-family: var(--owl-font-body); color: var(--owl-foreground); background: var(--owl-card); border: 2px solid var(--owl-glass-border); border-radius: var(--owl-radius-xl); cursor: pointer; box-shadow: 0 4px 0 0 var(--owl-3d-shadow); transition: all var(--owl-transition-normal);';
  backBtn.textContent = '\u8fd4\u56de\u9996\u9875';
  backBtn.addEventListener('mouseenter', function() { this.style.transform = 'translateY(-1px)'; this.style.boxShadow = '0 5px 0 0 var(--owl-3d-shadow)'; });
  backBtn.addEventListener('mouseleave', function() { this.style.transform = 'translateY(0)'; this.style.boxShadow = '0 4px 0 0 var(--owl-3d-shadow)'; });
  backBtn.addEventListener('mousedown', function() { this.style.transform = 'translateY(2px)'; this.style.boxShadow = '0 2px 0 0 var(--owl-3d-shadow)'; });
  backBtn.addEventListener('mouseup', function() { this.style.transform = 'translateY(0)'; this.style.boxShadow = '0 4px 0 0 var(--owl-3d-shadow)'; });
  backBtn.addEventListener('click', function() { window.location.href = './'; });
  wrapper.appendChild(backBtn);

  container.appendChild(wrapper);

  // 3-second countdown
  var seconds = 3;
  var timer = setInterval(function() {
    seconds--;
    var el = document.getElementById('owl-no-results-countdown');
    if (!el) { clearInterval(timer); return; }
    if (seconds <= 0) {
      clearInterval(timer);
      window.location.href = './';
    } else {
      el.textContent = seconds + ' \u79d2\u540e\u81ea\u52a8\u8fd4\u56de\u9996\u9875...';
    }
  }, 1000);
}

function escapeHtml(str) {
  var div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* === Create Result Card === */
function createResultCard(result, index) {
  var card = document.createElement('article');
  card.className = 'owl-result-card';
  card.dataset.pageId = result.id;
  card.style.cssText = 'padding: 20px; background: var(--owl-card); border: 2px solid var(--owl-glass-border); border-radius: var(--owl-radius-lg); transition: transform var(--owl-transition-normal); animation: owl-fade-in var(--owl-transition-slow) ' + (400 + index * 100) + 'ms both;';

  var h3 = document.createElement('h3');
  h3.style.cssText = 'font-size: var(--owl-text-xl); font-weight: var(--owl-weight-bold); color: var(--owl-primary); margin-bottom: 4px; cursor: pointer; transition: text-decoration var(--owl-transition-fast);';
  h3.textContent = result.title || '';
  h3.addEventListener('mouseenter', function() { this.style.textDecoration = 'underline'; });
  h3.addEventListener('mouseleave', function() { this.style.textDecoration = 'none'; });
  h3.addEventListener('click', function() {
    apiPost('/api/click', {page_id: result.id, query: currentQuery}).then(function() {
      window.open(result.url, '_blank');
    }).catch(function() {
      window.open(result.url, '_blank');
    });
  });
  card.appendChild(h3);

  var urlP = document.createElement('p');
  urlP.style.cssText = 'font-size: var(--owl-text-xs); color: var(--owl-muted); font-family: var(--owl-font-mono); margin-bottom: 10px;';
  urlP.textContent = result.url || '';
  card.appendChild(urlP);

  var snippetP = document.createElement('p');
  snippetP.style.cssText = 'font-size: var(--owl-text-sm); color: var(--owl-muted); font-weight: var(--owl-weight-medium); line-height: var(--owl-leading-relaxed); display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;';
  snippetP.innerHTML = result.snippet || '';
  card.appendChild(snippetP);

  var metaDiv = document.createElement('div');
  metaDiv.style.cssText = 'display: flex; align-items: center; gap: 8px; margin-top: 12px;';
  var dateSpan = document.createElement('span');
  dateSpan.style.cssText = 'font-size: var(--owl-text-xs); color: var(--owl-muted); font-weight: var(--owl-weight-medium);';
  dateSpan.textContent = result.date || '';
  metaDiv.appendChild(dateSpan);
  var sepSpan = document.createElement('span');
  sepSpan.style.cssText = 'font-size: var(--owl-text-xs); color: var(--owl-subtle);';
  sepSpan.textContent = '|';
  metaDiv.appendChild(sepSpan);
  var domainSpan = document.createElement('span');
  domainSpan.style.cssText = 'font-size: var(--owl-text-xs); color: var(--owl-muted); font-weight: var(--owl-weight-medium);';
  domainSpan.textContent = result.domain || '';
  metaDiv.appendChild(domainSpan);
  card.appendChild(metaDiv);

  return card;
}

/* === Render Pagination === */
function renderPagination(data) {
  var nav = document.getElementById('owl-pagination');
  if (!nav) return;
  nav.innerHTML = '';
  var totalPages = data.total_pages || 1;
  var currentPageNum = data.page || 1;

  var prevBtn = document.createElement('button');
  prevBtn.textContent = '\u4e0a\u4e00\u9875';
  var prevBase = 'padding: 8px 18px; font-size: var(--owl-text-sm); font-weight: var(--owl-weight-bold); font-family: var(--owl-font-body); background: var(--owl-card); border: 2px solid var(--owl-glass-border); border-radius: var(--owl-radius-xl); box-shadow: 0 4px 0 0 var(--owl-3d-shadow); transition: all var(--owl-transition-normal);';
  if (currentPageNum <= 1) {
    prevBtn.disabled = true;
    prevBtn.style.cssText = prevBase + ' color: var(--owl-subtle); cursor: not-allowed; opacity: 0.5;';
  } else {
    prevBtn.style.cssText = prevBase + ' color: var(--owl-foreground); cursor: pointer;';
    add3dHover(prevBtn);
    prevBtn.addEventListener('click', function() { performSearch(currentQuery, currentPageNum - 1); });
  }
  nav.appendChild(prevBtn);

  for (var i = 1; i <= totalPages; i++) {
    (function(pageNum) {
      var pageBtn = document.createElement('button');
      pageBtn.className = 'page-btn';
      pageBtn.textContent = pageNum;
      if (pageNum === currentPageNum) {
        pageBtn.classList.add('active');
        pageBtn.style.cssText = 'padding: 8px 14px; font-size: var(--owl-text-sm); font-weight: var(--owl-weight-bold); font-family: var(--owl-font-body); background: #0CC0B5; color: #FFF9E3; border: 2px solid #0CC0B5; border-radius: var(--owl-radius-xl); cursor: pointer; transition: all var(--owl-transition-normal);';
      } else {
        pageBtn.style.cssText = 'padding: 8px 14px; font-size: var(--owl-text-sm); font-weight: var(--owl-weight-semibold); font-family: var(--owl-font-body); background: var(--owl-card); color: var(--owl-foreground); border: 2px solid var(--owl-glass-border); border-radius: var(--owl-radius-xl); cursor: pointer; transition: all var(--owl-transition-normal);';
        pageBtn.addEventListener('mouseenter', function() { this.style.borderColor = '#0CC0B5'; this.style.color = '#0CC0B5'; });
        pageBtn.addEventListener('mouseleave', function() { this.style.borderColor = 'var(--owl-glass-border)'; this.style.color = 'var(--owl-foreground)'; });
        pageBtn.addEventListener('click', function() { performSearch(currentQuery, pageNum); });
      }
      nav.appendChild(pageBtn);
    })(i);
  }

  var nextBtn = document.createElement('button');
  nextBtn.textContent = '\u4e0b\u4e00\u9875';
  var nextBase = 'padding: 8px 18px; font-size: var(--owl-text-sm); font-weight: var(--owl-weight-bold); font-family: var(--owl-font-body); background: var(--owl-card); border: 2px solid var(--owl-glass-border); border-radius: var(--owl-radius-xl); box-shadow: 0 4px 0 0 var(--owl-3d-shadow); transition: all var(--owl-transition-normal);';
  if (currentPageNum >= totalPages) {
    nextBtn.disabled = true;
    nextBtn.style.cssText = nextBase + ' color: var(--owl-subtle); cursor: not-allowed; opacity: 0.5;';
  } else {
    nextBtn.style.cssText = nextBase + ' color: var(--owl-foreground); cursor: pointer;';
    add3dHover(nextBtn);
    nextBtn.addEventListener('click', function() { performSearch(currentQuery, currentPageNum + 1); });
  }
  nav.appendChild(nextBtn);
}

function add3dHover(btn) {
  btn.addEventListener('mouseenter', function() { this.style.transform = 'translateY(-1px)'; this.style.boxShadow = '0 5px 0 0 var(--owl-3d-shadow)'; });
  btn.addEventListener('mouseleave', function() { this.style.transform = 'translateY(0)'; this.style.boxShadow = '0 4px 0 0 var(--owl-3d-shadow)'; });
  btn.addEventListener('mousedown', function() { this.style.transform = 'translateY(2px)'; this.style.boxShadow = '0 2px 0 0 var(--owl-3d-shadow)'; });
  btn.addEventListener('mouseup', function() { this.style.transform = 'translateY(0)'; this.style.boxShadow = '0 4px 0 0 var(--owl-3d-shadow)'; });
}

/* === Render Sidebar === */
function renderSidebar(data) {
  var trendingList = document.getElementById('owl-trending-list');
  if (trendingList) {
    trendingList.innerHTML = '';
    var trending = data.trending || [];
    if (trending.length === 0) {
      apiGet('/api/trending').then(function(tData) {
        renderTrendingItems(tData.trending || []);
      }).catch(function() {});
    } else {
      renderTrendingItems(trending);
    }
  }

  var relatedList = document.getElementById('owl-related-list');
  if (relatedList) {
    relatedList.innerHTML = '';
    var related = data.related || [];
    if (related.length === 0 && currentQuery) {
      apiGet('/api/related?q=' + encodeURIComponent(currentQuery)).then(function(rData) {
        renderRelatedItems(rData.related || []);
      }).catch(function() {});
    } else {
      renderRelatedItems(related);
    }
  }
}

function renderTrendingItems(items) {
  var list = document.getElementById('owl-trending-list');
  if (!list) return;
  list.innerHTML = '';
  var rankColors = ['#e05a5a', '#f5a623', '#f5c31c'];
  items.forEach(function(item, index) {
    var li = document.createElement('li');
    var borderStyle = index < items.length - 1 ? ' border-bottom: 1px dashed var(--owl-subtle);' : '';
    li.style.cssText = 'padding: 8px 10px; border-radius: var(--owl-radius-sm); font-size: var(--owl-text-sm); font-weight: var(--owl-weight-medium); cursor: pointer; transition: background var(--owl-transition-fast); display: flex; align-items: center; gap: 10px;' + borderStyle;
    li.addEventListener('mouseenter', function() { this.style.background = 'var(--owl-primary-bg)'; });
    li.addEventListener('mouseleave', function() { this.style.background = 'transparent'; });
    li.addEventListener('click', function() { triggerSearch(item); });

    if (index < 3) {
      var rankSpan = document.createElement('span');
      rankSpan.style.cssText = 'display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; border-radius: 6px; background: ' + rankColors[index] + '; color: #fff; font-size: 12px; font-weight: 800; flex-shrink: 0;';
      rankSpan.textContent = (index + 1);
      li.appendChild(rankSpan);
      var textSpan = document.createElement('span');
      textSpan.style.color = 'var(--owl-foreground)';
      textSpan.textContent = item;
      li.appendChild(textSpan);
    } else {
      var icon = document.createElement('i');
      icon.setAttribute('data-lucide', 'corner-down-right');
      icon.style.cssText = 'width: 14px; height: 14px; color: var(--owl-muted); flex-shrink: 0;';
      li.appendChild(icon);
      var textSpan = document.createElement('span');
      textSpan.style.color = 'var(--owl-primary)';
      textSpan.textContent = item;
      li.appendChild(textSpan);
    }
    list.appendChild(li);
  });
  if (window.lucide) lucide.createIcons();
}

function renderRelatedItems(items) {
  var list = document.getElementById('owl-related-list');
  if (!list) return;
  list.innerHTML = '';
  items.forEach(function(item, index) {
    var li = document.createElement('li');
    var borderStyle = index < items.length - 1 ? ' border-bottom: 1px dashed var(--owl-subtle);' : '';
    li.style.cssText = 'padding: 8px 10px; border-radius: var(--owl-radius-sm); font-size: var(--owl-text-sm); color: var(--owl-primary); font-weight: var(--owl-weight-medium); cursor: pointer; transition: background var(--owl-transition-fast); display: flex; align-items: center; gap: 10px;' + borderStyle;
    li.addEventListener('mouseenter', function() { this.style.background = 'var(--owl-primary-bg)'; });
    li.addEventListener('mouseleave', function() { this.style.background = 'transparent'; });
    li.addEventListener('click', function() { triggerSearch(item); });

    var icon = document.createElement('i');
    icon.setAttribute('data-lucide', 'corner-down-right');
    icon.style.cssText = 'width: 14px; height: 14px; color: var(--owl-muted); flex-shrink: 0;';
    li.appendChild(icon);
    var textSpan = document.createElement('span');
    textSpan.textContent = item;
    li.appendChild(textSpan);
    list.appendChild(li);
  });
  if (window.lucide) lucide.createIcons();
}

function triggerSearch(term) {
  var input = document.querySelector('#owl-search-form input[type="text"]');
  if (input) input.value = term;
  var newUrl = window.location.pathname + '?q=' + encodeURIComponent(term);
  history.pushState({q: term}, '', newUrl);
  performSearch(term, 1);
  window.scrollTo(0, 0);
}

/* === Update Stats === */
function updateStats(data) {
  var totalEl = document.getElementById('owl-stat-total');
  if (totalEl) totalEl.textContent = (data.total || 0) + ' \u6761';
  var tookEl = document.getElementById('owl-stat-took');
  if (tookEl && typeof data.took === 'number') tookEl.textContent = data.took.toFixed(4) + ' \u79d2';
  var pageEl = document.getElementById('owl-stat-page');
  if (pageEl) pageEl.textContent = '\u7b2c ' + (data.page || 1) + ' / ' + (data.total_pages || 1) + ' \u9875';
}

/* === Feedback Button Injection (XSS-safe) === */
function injectFeedbackButtons() {
  document.querySelectorAll('.owl-result-card').forEach(function (card) {
    if (card.querySelector('.owl-feedback-btn')) return;
    var btn = document.createElement('button');
    btn.className = 'owl-feedback-btn';
    btn.setAttribute('aria-label', '\u53cd\u9988');
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/></svg>';
    card.appendChild(btn);
    var pageId = parseInt(card.dataset.pageId || '0', 10);

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      // Close any existing dropdown
      document.querySelectorAll('.owl-feedback-dropdown').forEach(function (d) { d.remove(); });

      var rect = btn.getBoundingClientRect();
      var dropdown = document.createElement('div');
      dropdown.className = 'owl-feedback-dropdown';
      dropdown.style.top = (rect.bottom + 4) + 'px';
      dropdown.style.left = (rect.right - 140) + 'px';
      if (rect.right - 140 < 4) dropdown.style.left = '4px';
      var options = ['\u76f8\u5173\u63a8\u8350', '\u4e0d\u611f\u5174\u8da3', '\u53cd\u9988\u610f\u89c1'];
      options.forEach(function (label) {
        var opt = document.createElement('div');
        opt.className = 'owl-feedback-option';
        // Use textContent for safety (no innerHTML with user data)
        opt.textContent = label;
        opt.addEventListener('click', function (ev) {
          ev.stopPropagation();
          dropdown.remove();
          apiPost('/api/feedback', {page_id: pageId, feedback_type: label}).catch(function () {});
          // Show checkmark (hardcoded SVG, safe)
          btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="var(--owl-primary)"><path d="M3 8l3.5 3.5L13 5" stroke="var(--owl-primary)" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
          setTimeout(function () {
            btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/></svg>';
          }, 1500);
        });
        dropdown.appendChild(opt);
      });
      document.body.appendChild(dropdown);
    });
  });
}

/* === Close dropdowns on click or scroll (rAF-throttled) === */
function closeDropdowns() {
  document.querySelectorAll('.owl-feedback-dropdown').forEach(function (d) { d.remove(); });
}
document.addEventListener('click', closeDropdowns);

var scrollTick = false;
document.addEventListener('scroll', function () {
  if (!scrollTick) {
    scrollTick = true;
    requestAnimationFrame(function () {
      closeDropdowns();
      scrollTick = false;
    });
  }
}, true);

/* === Search Stats localStorage reader === */
(function () {
  function applyStats(show) {
    var statsEl = document.getElementById('owl-search-stats');
    if (statsEl) statsEl.style.display = show ? '' : 'none';
  }
  var showStats = localStorage.getItem('owl-show-stats') !== '0';
  applyStats(showStats);
  window.addEventListener('storage', function (e) {
    if (e.key === 'owl-show-stats') {
      applyStats(e.newValue !== '0');
    }
  });
})();

/* === Hide Related & Trending localStorage reader === */
function applyHideRelated(hide) {
  var trending = document.querySelector('.owl-sidebar');
  if (trending) {
    var trendingCard = document.getElementById('owl-trending-list');
    var relatedCard = document.getElementById('owl-related-list');
    if (trendingCard) trendingCard.closest('div[onmouseenter]') && (trendingCard.closest('div[onmouseenter]').style.display = hide ? 'none' : '');
    if (relatedCard) relatedCard.closest('div[onmouseenter]') && (relatedCard.closest('div[onmouseenter]').style.display = hide ? 'none' : '');
  }
}
(function () {
  var hideRelated = localStorage.getItem('owl-hide-related') === '1';
  applyHideRelated(hideRelated);
  window.addEventListener('storage', function (e) {
    if (e.key === 'owl-hide-related') {
      applyHideRelated(e.newValue === '1');
    }
  });
})();

/* === Form Submit Handler === */
function initSearchForm() {
  var searchForm = document.getElementById('owl-search-form');
  if (!searchForm) return;
  searchForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var input = searchForm.querySelector('input[type="text"]');
    var q = (input ? input.value : '').trim();
    if (!q) return;
    var newUrl = 'search?q=' + encodeURIComponent(q);
    if (typeof OwlRouter !== 'undefined' && OwlRouter.navigate) {
      OwlRouter.navigate(newUrl);
    } else {
      window.location.href = newUrl;
    }
  });
}

/* === Initialize results page === */
function initResultsPage() {
  currentQuery = '';
  currentPage = 1;
  initClearButton();
  initSearchForm();

  if (typeof lucide !== 'undefined' && lucide.createIcons) {
    lucide.createIcons();
  }

  var params = new URLSearchParams(window.location.search);
  var q = (params.get('q') || '').trim();
  var input = document.querySelector('#owl-search-form input[type="text"]');
  if (q) {
    if (input) input.value = q;
    performSearch(q, 1);
  } else {
    apiGet('/trending').then(function (data) {
      renderTrendingItems(data.trending || []);
    }).catch(function () {});
  }

  var hideRelated = localStorage.getItem('owl-hide-related') === '1';
  applyHideRelated(hideRelated);
}

document.addEventListener('DOMContentLoaded', function () {
  if (document.getElementById('owl-results-container')) {
    initResultsPage();
  }
});

window.addEventListener('popstate', function () {
  if (typeof OwlRouter !== 'undefined') return;
  var params = new URLSearchParams(window.location.search);
  var q = (params.get('q') || '').trim();
  var input = document.querySelector('#owl-search-form input[type="text"]');
  if (input) input.value = q;
  if (q) {
    performSearch(q, 1);
  }
});
