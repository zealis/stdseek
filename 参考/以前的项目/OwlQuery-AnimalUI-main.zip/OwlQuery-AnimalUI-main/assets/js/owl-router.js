(function () {
  'use strict';

  var OwlRouter = {
    currentPage: null,
    pageCache: {},
    isTransitioning: false
  };

  var PAGE_MAP = {
    'index': { title: 'OwlQuery - 极速搜索，洞见一切', file: 'index.html' },
    'results': { title: '搜索结果 - OwlQuery', file: 'results.html' },
    'settings': { title: '快捷设置 - OwlQuery', file: 'settings.html' }
  };

  function getPageNameFromPath(path) {
    var filename = path.split('/').pop() || '';
    var pathname = path.split('?')[0];
    if (pathname.endsWith('/search') || pathname.endsWith('/search/')) return 'results';
    if (filename === '' || filename === '/' || filename === 'index.html') return 'index';
    if (filename === 'results.html') return 'results';
    if (filename === 'settings.html') return 'settings';
    return 'index';
  }

  function getPageFile(pageName) {
    return PAGE_MAP[pageName] ? PAGE_MAP[pageName].file : 'index.html';
  }

  function getPageTitle(pageName) {
    return PAGE_MAP[pageName] ? PAGE_MAP[pageName].title : 'OwlQuery';
  }

  function fetchPage(pageName) {
    if (OwlRouter.pageCache[pageName]) {
      return Promise.resolve(OwlRouter.pageCache[pageName]);
    }
    var file = getPageFile(pageName);
    return fetch(file, { cache: 'force-cache' })
      .then(function (res) { return res.text(); })
      .then(function (html) {
        OwlRouter.pageCache[pageName] = html;
        return html;
      });
  }

  function extractMainContent(html) {
    var parser = new DOMParser();
    var doc = parser.parseFromString(html, 'text/html');
    var main = doc.querySelector('main');
    var footer = doc.querySelector('footer');
    return { main: main ? main.innerHTML : '', footer: footer ? footer.outerHTML : '', headStyles: doc.head.innerHTML };
  }

  function runPageScripts(pageName) {
    var scriptMap = {
      'index': function () {
        var s1 = document.querySelectorAll('main script');
        s1.forEach(function (s) {
          var newScript = document.createElement('script');
          if (s.src) {
            newScript.src = s.src;
          } else {
            newScript.textContent = s.textContent;
          }
          s.parentNode.replaceChild(newScript, s);
        });
      },
      'results': function () {
        if (typeof initResultsPage === 'function') {
          initResultsPage();
        }
        if (typeof lucide !== 'undefined' && lucide.createIcons) {
          lucide.createIcons();
        }
      },
      'settings': function () {
        if (typeof initSettingsPage === 'function') {
          initSettingsPage();
        }
        if (typeof lucide !== 'undefined' && lucide.createIcons) {
          lucide.createIcons();
        }
      }
    };
    if (scriptMap[pageName]) {
      setTimeout(scriptMap[pageName], 50);
    }
  }

  function executeInlineScripts(container) {
    var scripts = container.querySelectorAll('script');
    scripts.forEach(function (oldScript) {
      var newScript = document.createElement('script');
      if (oldScript.src) {
        newScript.src = oldScript.src;
      } else {
        newScript.textContent = oldScript.textContent;
      }
      oldScript.parentNode.replaceChild(newScript, oldScript);
    });
  }

  function transitionTo(pageName, searchQuery) {
    if (OwlRouter.isTransitioning) return;
    if (OwlRouter.currentPage === pageName && !searchQuery) return;

    OwlRouter.isTransitioning = true;

    var mainEl = document.querySelector('main');
    var footerEl = document.querySelector('footer');

    if (mainEl) {
      mainEl.style.opacity = '0';
      mainEl.style.transform = 'translateY(8px)';
      mainEl.style.transition = 'opacity 200ms ease, transform 200ms ease';
    }

    fetchPage(pageName).then(function (html) {
      var content = extractMainContent(html);

      setTimeout(function () {
        if (mainEl && content.main) {
          mainEl.innerHTML = content.main;
          executeInlineScripts(mainEl);
          mainEl.style.opacity = '0';
          mainEl.style.transform = 'translateY(8px)';
          requestAnimationFrame(function () {
            mainEl.style.opacity = '1';
            mainEl.style.transform = 'translateY(0)';
          });
        }

        if (footerEl && content.footer) {
          var tmp = document.createElement('div');
          tmp.innerHTML = content.footer;
          if (tmp.firstElementChild) {
            footerEl.innerHTML = tmp.firstElementChild.innerHTML;
          }
        }

        document.title = getPageTitle(pageName);
        OwlRouter.currentPage = pageName;

        bindInternalLinks();
        runPageScripts(pageName);

        setTimeout(function () {
          OwlRouter.isTransitioning = false;
        }, 250);
      }, 180);
    }).catch(function (err) {
      console.error('Page load failed:', err);
      window.location.href = getPageFile(pageName);
    });
  }

  function navigateTo(url, pushState) {
    if (pushState === undefined) pushState = true;

    var pathname = url.split('?')[0];
    var search = url.indexOf('?') > -1 ? url.substring(url.indexOf('?')) : '';
    var pageName = getPageNameFromPath(pathname);

    if (pushState) {
      history.pushState({ page: pageName, search: search }, '', url);
    }

    transitionTo(pageName, search);
    window.scrollTo(0, 0);
  }

  function bindInternalLinks() {
    var links = document.querySelectorAll('a[href]');
    links.forEach(function (link) {
      var href = link.getAttribute('href');
      if (!href) return;
      if (href.startsWith('http') || href.startsWith('//') || href.startsWith('#') || href.startsWith('mailto:')) return;
      if (href.indexOf('.html') === -1 && href !== './' && href !== '/' && !href.endsWith('/')) return;

      if (link.dataset.routerBound) return;
      link.dataset.routerBound = 'true';

      link.addEventListener('click', function (e) {
        if (e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        var target = link.getAttribute('href');
        if (target === './' || target === '/') {
          navigateTo('./');
        } else {
          navigateTo(target);
        }
      });
    });

    var homeForm = document.getElementById('owl-home-search-form');
    if (homeForm && !homeForm.dataset.routerBound) {
      homeForm.dataset.routerBound = 'true';
      homeForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = homeForm.querySelector('input[name="q"]');
        var q = (input ? input.value : '').trim();
        if (!q) return;
        navigateTo('search?q=' + encodeURIComponent(q));
      });
    }
  }

  function handlePopState(e) {
    var pageName = getPageNameFromPath(window.location.pathname);
    var search = window.location.search;
    transitionTo(pageName, search);
  }

  OwlRouter.navigate = navigateTo;
  OwlRouter.getCurrentPage = function () { return OwlRouter.currentPage; };

  window.OwlRouter = OwlRouter;

  document.addEventListener('DOMContentLoaded', function () {
    OwlRouter.currentPage = getPageNameFromPath(window.location.pathname);
    bindInternalLinks();
    window.addEventListener('popstate', handlePopState);

    var pageName = OwlRouter.currentPage;
    if (pageName === 'search' || pageName === 'results') {
      if (typeof initResultsPage === 'function') {
        initResultsPage();
      }
    } else if (pageName === 'settings') {
      if (typeof initSettingsPage === 'function') {
        initSettingsPage();
      }
    }
  });
})();
