/* OwlQuery Settings Page Scripts */

function initSettingsPage() {
  'use strict';

  var toggleMap = {
    'toggle-safe-search': 'owl-safe-search',
    'toggle-exact-match': 'owl-exact-match',
    'toggle-live-preview': 'owl-live-preview',
    'toggle-show-snippet': 'owl-show-snippet',
    'toggle-animations': 'owl-animations',
    'toggle-compact-mode': 'owl-compact-mode',
    'toggle-show-stats': 'owl-show-stats',
    'toggle-hide-related': 'owl-hide-related'
  };

  var defaults = {
    'owl-safe-search': '1',
    'owl-exact-match': '0',
    'owl-live-preview': '1',
    'owl-show-snippet': '1',
    'owl-animations': '1',
    'owl-compact-mode': '0',
    'owl-show-stats': '1',
    'owl-hide-related': '0'
  };

  var toggles = document.querySelectorAll('.owl-toggle');

  function updateVisual(input) {
    var track = input.parentElement.querySelector('.owl-toggle__track');
    var thumb = input.parentElement.querySelector('.owl-toggle__thumb');
    if (!track || !thumb) return;
    if (input.checked) {
      track.style.background = '#86d67a';
      track.style.boxShadow = 'inset 0 2px 4px rgba(90, 158, 30, 0.20)';
      track.style.borderColor = '#6fba2c';
      thumb.style.left = 'calc(100% - 24px)';
      thumb.style.borderColor = '#6fba2c';
      thumb.style.background = 'rgb(247,243,223)';
    } else {
      track.style.background = '#d4c9b4';
      track.style.boxShadow = 'inset 0 2px 4px rgba(114, 93, 66, 0.15)';
      track.style.borderColor = '#c4b89e';
      thumb.style.left = '2px';
      thumb.style.borderColor = '#c4b89e';
      thumb.style.background = 'rgb(247,243,223)';
    }
  }

  toggles.forEach(function(toggle) {
    var newToggle = toggle.cloneNode(true);
    toggle.parentNode.replaceChild(newToggle, toggle);
  });

  toggles = document.querySelectorAll('.owl-toggle');

  toggles.forEach(function(toggle) {
    toggle.addEventListener('click', function(e) {
      e.preventDefault();
      var input = toggle.querySelector('input[type="checkbox"]');
      if (!input) return;
      input.checked = !input.checked;
      updateVisual(input);
      var key = toggleMap[input.id];
      if (key) {
        localStorage.setItem(key, input.checked ? '1' : '0');
      }
    });
  });

  function loadSettings() {
    toggles.forEach(function(toggle) {
      var input = toggle.querySelector('input[type="checkbox"]');
      if (!input) return;
      var key = toggleMap[input.id];
      var val = defaults[key] || '0';
      if (key) {
        var stored = localStorage.getItem(key);
        if (stored !== null) {
          val = stored;
        }
      }
      input.checked = val === '1';
      updateVisual(input);
    });
  }

  loadSettings();

  if (typeof lucide !== 'undefined' && lucide.createIcons) {
    lucide.createIcons();
  }

  var backLink = document.querySelector('[data-dom-id="back-to-search"]');
  if (backLink) {
    backLink.addEventListener('click', function(e) {
      if (typeof OwlRouter !== 'undefined' && OwlRouter.navigate) {
        e.preventDefault();
        OwlRouter.navigate('search');
      }
    });
  }

  var API_BASE = (typeof OwlConfig !== 'undefined' && OwlConfig.apiBase) || '/api';
  fetch(API_BASE + '/version').then(function(r) { return r.json(); }).then(function(data) {
    var versionEl = document.getElementById('owl-version');
    if (versionEl && data.version) {
      versionEl.textContent = data.version;
    }
  }).catch(function() {});
}

document.addEventListener('DOMContentLoaded', function () {
  if (document.querySelector('.owl-settings-card')) {
    initSettingsPage();
  }
});
