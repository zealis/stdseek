// Initialize Lucide icons
lucide.createIcons();

/* === OwlQuery Common API Client === */
var OwlAPI = {
  base: (typeof OwlConfig !== 'undefined' && OwlConfig.apiBase) || '/api',
  get: function(path) {
    return fetch(this.base + path).then(function(r) {
      if (!r.ok) throw new Error('API error: ' + r.status);
      return r.json();
    });
  },
  post: function(path, body) {
    return fetch(this.base + path, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body || {})
    }).then(function(r) {
      if (!r.ok) throw new Error('API error: ' + r.status);
      return r.json();
    });
  },
  put: function(path, body) {
    return fetch(this.base + path, {
      method: 'PUT',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body || {})
    }).then(function(r) {
      if (!r.ok) throw new Error('API error: ' + r.status);
      return r.json();
    });
  },
  del: function(path) {
    return fetch(this.base + path, {
      method: 'DELETE'
    }).then(function(r) {
      if (!r.ok) throw new Error('API error: ' + r.status);
      return r.json();
    });
  }
};
