/* ==========================================================================
   OwlQuery Custom JavaScript
   ==========================================================================
   在此文件中添加自定义 JS 代码，例如：
   - 网站访客统计（Google Analytics、百度统计、友盟+ 等）
   - 第三方服务集成
   - 自定义埋点

   注意事项：
   - 此文件在所有页面加载，代码会在 DOM 就绪后执行
   - 请勿修改其他核心 JS 文件
   - 升级时此文件不会被覆盖（请自行备份）
   ========================================================================== */

(function () {
  'use strict';

  // ==========================================
  // 示例：Google Analytics 4（取消注释并替换 ID）
  // ==========================================
  /*
  var GA_ID = 'G-XXXXXXXXXX';
  var s = document.createElement('script');
  s.async = true;
  s.src = 'https://www.googletagmanager.com/gtag/js?id=' + GA_ID;
  document.head.appendChild(s);

  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', GA_ID);
  */

  // ==========================================
  // 示例：百度统计（取消注释并替换 ID）
  // ==========================================
  /*
  var _hmt = _hmt || [];
  var hm = document.createElement('script');
  hm.src = 'https://hm.baidu.com/hm.js?你的ID';
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(hm, s);
  */

  // ==========================================
  // 在此添加你的自定义代码
  // ==========================================

})();